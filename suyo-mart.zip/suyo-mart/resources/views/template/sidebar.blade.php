  <!-- ============================================== SIDEBAR ============================================== -->

  <div class="sidebar-fix">
      <div class="col-xs-12 col-sm-12 col-md-3  sidebar" style="margin-top:5rem ">

          <!-- ================================== TOP NAVIGATION ================================== -->
          <div class="side-menu animate-dropdown outer-bottom-xs">
              <div class="head"><i class="icon fa fa-align-justify fa-fw"></i> Categories</div>
              <nav class="yamm megamenu-horizontal">
                  <ul class="nav">
                      <li class="dropdown menu-item"> <a href="{{ route('home') }}"><i class="icon fa fa-shopping-bag"
                                  aria-hidden="true"></i>ALL
                              PRODUK</a>

                      </li>
                      <!-- /.menu-item -->
                      <li class="dropdown menu-item"> <a href="{{ route('indonesia') }}"><i class="icon fa fa-laptop"
                                  aria-hidden="true"></i>INDONESIAN
                              FOOD</a>
                          <!-- ================================== MEGAMENU VERTICAL ================================== -->
                      </li>
                      <!-- /.menu-item -->
                      <li class="dropdown menu-item"> <a href="{{ route('korea') }}"><i
                                  class="icon fa fa-heartbeat"></i>KOREAN FOOD</a>

                      </li>
                      <!-- /.menu-item -->
                      <li class="dropdown menu-item"> <a href="{{ route('japan') }}"><i
                                  class="icon fa fa-paper-plane"></i>JAPANESE FOOD</a>
                          <!-- /.dropdown-menu -->
                      </li>
                      <!-- /.menu-item -->

                      <li class="dropdown menu-item"> <a href="{{ route('india') }}"><i
                                  class="icon fa fa-futbol-o"></i>INDIA FOOD</a>
                          <!-- ================================== MEGAMENU VERTICAL ================================== -->
                          <!-- /.dropdown-menu -->
                      </li>
                      <!-- /.menu-item -->
                  </ul>
                  <!-- /.nav -->
              </nav>
              <!-- /.megamenu-horizontal -->
          </div>
          <!-- /.side-menu -->
          <!-- ================================== TOP NAVIGATION : END ================================== -->
      </div>
  </div>
  <!-- /.sidemenu-holder -->
  <!-- ============================================== SIDEBAR : END ============================================== -->
