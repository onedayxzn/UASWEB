@extends('layouts.master')
@section('title', 'Produk')
@section('content')

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Daftar Produk</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="">Daftar Produk</a></div>
                </div>
            </div>

            <div class="section-body">


            </div>




            @push('page-scripts')

            @endpush

            @push('after-script')



            @endpush
        @endsection
