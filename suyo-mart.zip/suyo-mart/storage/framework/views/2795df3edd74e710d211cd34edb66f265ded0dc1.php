<header class="header-style-1">

    <!-- ============================================== TOP MENU ============================================== -->
    <div class="top-bar animate-dropdown">
        <div class="container">
            <div class="header-top-inner">
                <div class="cnt-account">
                    <ul class="list-unstyled">
                        <!-- /.col -->
                    </ul>
                </div>

                <!-- /.cnt-account -->

                <!-- /.list-unstyled -->
            </div>
            <!-- /.cnt-cart -->

        </div>
        <!-- /.header-top-inner -->
    </div>
    <!-- /.container -->
    </div>
    <!-- /.header-top -->
    <!-- ============================================== TOP MENU : END ============================================== -->
    <div class="main-header">
        <div class="container">

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-3 logo-holder">
                    <!-- ============================================================= LOGO ============================================================= -->
                    <div class="logo"> <a href="/"> <img src="<?php echo e(asset('assetss/images/Logo-SUYOMART.png')); ?>"
                                alt="logo" width="230px" height="60px"> </a> </div>
                    <!-- /.logo -->
                    <!-- ============================================================= LOGO : END ============================================================= -->
                </div>
                <!-- /.logo-holder -->

                <div class="col-lg-7 col-md-6 col-sm-8 col-xs-12 top-search-holder">
                    <!-- /.contact-row -->
                    <!-- ============================================================= SEARCH AREA ============================================================= -->
                    <div class="search-area">
                        <form action="<?php echo e(route('carii')); ?>">
                            <div class="control-group">
                                <input class="search-field" name="cari"
                                    placeholder="Cari bedasarkan nama produk atau ketegori" />
                                <button type="submit" class="search-button" href="#"></button>
                            </div>
                        </form>
                    </div>
                    <!-- /.search-area -->
                    <!-- ============================================================= SEARCH AREA : END ============================================================= -->
                </div>
                <!-- /.top-search-holder -->



            </div>
            <!-- /.row -->

        </div>
        <!-- /.container -->

    </div>
    <!-- /.main-header -->

    <!-- ============================================== NAVBAR ============================================== -->

    <!-- /.header-nav -->
    <!-- ============================================== NAVBAR : END ============================================== -->

</header>
<?php /**PATH C:\xampp\htdocs\suyo-mart\resources\views/template/header.blade.php ENDPATH**/ ?>