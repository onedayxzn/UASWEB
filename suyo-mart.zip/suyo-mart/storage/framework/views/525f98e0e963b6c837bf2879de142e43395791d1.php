
<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Edit Produk</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Dash</a></div>
                    <div class="breadcrumb-item"><a href="#">Dash</a></div>
                    <div class="breadcrumb-item"><a href="#">Dash</a></div>
                </div>
            </div>

            <div class="section-body">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="card">
                            <form action="<?php echo e(route('editProdukProses', $produk->id)); ?>" method="POST">
                                <div class="card-body">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('patch'); ?>
                                    <div class="form-group">
                                        <label>Nama Produk</label>
                                        <input type="text" name="NAMA_PRODUK" class="form-control"
                                            value="<?php echo e($produk->NAMA_PRODUK); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Pilih kategori</label>
                                        <select class="form-control" name="KATEGORI">
                                            <option value="<?php echo e($produk->KATEGORI); ?>">
                                                <?php echo e($produk->KATEGORI); ?>

                                            </option>
                                            <option value="INDONESIA FOOD">INDONESIA FOOD</option>
                                            <option value="JAPANESE FOOD">JAPANESE FOOD</option>
                                            <option value="JAPANESE FOOD">JAPANESE FOOD</option>
                                            <option value="JAPANESE FOOD">JAPANESE FOOD</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Jumlah</label>
                                        <input type="text" name="JUMLAH" class="form-control"
                                            value="<?php echo e($produk->JUMLAH); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Harga Satuan</label>
                                        <input type="text" name="HARGA" class="form-control" value="<?php echo e($produk->HARGA); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Ubah gambar</label>
                                        <input type="file" name="GAMBAR" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Deskripsi</label>
                                        <textarea style="width:40rem; height:30rem" type="text" name="DESKRIPSI"
                                            class="form-control border border-secondary"> <?php echo e($produk->DESKRIPSI); ?></textarea>
                                    </div>
                                    <div class="card-footer text-right">
                                        <button class="btn btn-primary mr-1" type="submit">Submit</button>
                                        <button class="btn btn-secondary" type="reset">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>



                <?php $__env->startPush('page-scripts'); ?>

                <?php $__env->stopPush(); ?>

            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\1. Kuliah\2. Semester 4\7. Pemograman WEB\suyo-mart\resources\views/editDataProduk.blade.php ENDPATH**/ ?>