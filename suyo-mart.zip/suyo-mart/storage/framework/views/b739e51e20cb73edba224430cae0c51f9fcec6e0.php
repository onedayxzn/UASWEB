
<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Daftar Produk</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('produk')); ?>">Daftar Produk</a></div>
                </div>
            </div>

            <div class="section-body">
                <div class="col-12 col-md-12 col-lg-12">
                    <a href="<?php echo e(route('tambahProduk')); ?>" class="btn btn-icon icon-left btn-primary"><i
                            class="far fa-edit"></i>Tambah Produk</a>
                    <hr>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="container">
                        <div class="row justify-content-md-center">
                            <?php $__currentLoopData = $allProduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 col-md-3 col-sm-3 col-lg-3 mr-5">
                                    <div class="card" style="width: 18rem;">
                                        <img src="<?php echo e(url('Image/'.$ap->GAMBAR)); ?>" class="card-img-top"
                                            style="width: 18rem; height: 14rem">
                                        <div class="card-body">
                                            <h5 class="card-title text-center"><?php echo e($ap->NAMA_PRODUK); ?></h5>
                                            <p class="card-text">ID_PRODUK : <?php echo e($ap->id); ?></p>
                                            <p class="card-text">KATEGORI : <?php echo e($ap->KATEGORI); ?></p>
                                            <p class="card-text">JUMLAH : <?php echo e($ap->JUMLAH); ?></p>
                                            <p class="card-text">HARGA Satuan: Rp. <?php echo e($ap->HARGA); ?></p>
                                            <a href="<?php echo e(route('editProduk', $ap->id)); ?>" class="btn btn-primary">Edit</a>
                                            <a href="<?php echo e(route('detailProduk', $ap->id)); ?>"
                                                class="btn btn-primary">detail</a>
                                            <a href="javascript:void(0)" onclick="$(this).find('form').submit()"
                                                class="btn btn-danger">
                                                <span class="fa fa-trash"> Hapus</span>
                                                <form action="<?php echo e(route('hapusProduk', $ap->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                </form>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    

                </div>

            </div>




            <?php $__env->startPush('page-scripts'); ?>

            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('after-script'); ?>



            <?php $__env->stopPush(); ?>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\1. Kuliah\2. Semester 4\7. Pemograman WEB\suyo-mart\resources\views/produk.blade.php ENDPATH**/ ?>