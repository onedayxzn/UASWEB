
<?php /**PATH C:\xampp\htdocs\suyo-mart\resources\views/checkout.blade.php ENDPATH**/ ?>