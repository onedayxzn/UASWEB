
<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Daftar Pesanan</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Daftar Pesanan</a></div>
                </div>
            </div>

            <div class="section-body">
                <div class="col-12 col-md-12 col-lg-12">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible show fade">
                            <div class="alert-body">
                                <button class="close" data-dismiss="alert">
                                    <span>x</span>
                                </button>
                                <?php echo e(session('status')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama Konsumen</th>
                                <th scope="col" hidden>Id produk</th>
                                <th scope="col">Nama Produk</th>
                                <th scope="col">Harga</th>
                                <th scope="col">Jumlah Beli</th>
                                <th scope="col">Jumlah Bayar</th>
                                <th scope="col">Tanggal Pesan</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($pesanan->firstItem() + $no); ?></th>
                                    <td><?php echo e($ps->NAMA_KONSUMEN); ?></td>
                                    <td hidden><?php echo e($ps->ID_PRODUK); ?></td>
                                    <td><?php echo e($ps->NAMA_PRODUK); ?></td>
                                    <td><?php echo e($ps->HARGA); ?></td>
                                    <td><?php echo e($ps->JUMLAH_BELI); ?></td>
                                    <td><?php echo e($ps->JUMLAH_BAYAR); ?></td>
                                    <td><?php echo e($ps->TANGGAL_PESAN); ?></td>
                                    <td>
                                        <a href="javascript:void(0)" onclick="$(this).find('form').submit()"
                                            class="btn btn-danger">
                                            <span class="fa fa-trash"> Hapus</span>
                                            <form action="<?php echo e(route('hapusPesanan', $ps->ID_PESANAN)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($pesanan->links()); ?>


            </div>




            <?php $__env->startPush('page-scripts'); ?>

            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('after-script'); ?>



            <?php $__env->stopPush(); ?>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\suyo-mart\resources\views/pesanan.blade.php ENDPATH**/ ?>