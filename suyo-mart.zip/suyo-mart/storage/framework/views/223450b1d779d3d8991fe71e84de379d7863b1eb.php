
<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Daftar Produk</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="">Daftar Produk</a></div>
                </div>
            </div>

            <div class="section-body">


            </div>




            <?php $__env->startPush('page-scripts'); ?>

            <?php $__env->stopPush(); ?>

            <?php $__env->startPush('after-script'); ?>



            <?php $__env->stopPush(); ?>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\1. Kuliah\2. Semester 4\7. Pemograman WEB\suyo-mart\resources\views/index.blade.php ENDPATH**/ ?>