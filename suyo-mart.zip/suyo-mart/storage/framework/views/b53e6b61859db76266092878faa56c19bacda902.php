<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html">SUYOmart</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">Stsad</a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Dashboard</li>
            <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-fire"></i><span>Dashboard</span></a>
                <ul class="dropdown-menu">
                    <li><a class="nav-link" href="index-0.html">General Dashboard</a></li>
                    <li><a class="nav-link" href="index.html">Ecommerce Dashboard</a></li>
                </ul>
            </li>
            <li class="active"><a class="nav-link" href="<?php echo e(route('produk')); ?>"><i class="bi bi-list"></i>
                    <span>PRODUK</span></a></li>
            <li class="active"><a class="nav-link" href="<?php echo e(route('produk')); ?>"><i class="bi bi-list"></i>
                    <span>PESANAN</span></a></li>
        </ul>
    </aside>
</div>
<?php /**PATH E:\1. Kuliah\2. Semester 4\7. Pemograman WEB\suyo-mart\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>