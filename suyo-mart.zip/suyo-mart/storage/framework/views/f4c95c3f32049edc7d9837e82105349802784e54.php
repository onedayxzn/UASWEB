
<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Detail Produk</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item"><a href="<?php echo e(route('produk')); ?>">Produk</a></div>
                    <div class="breadcrumb-item active"><a href="#"><?php echo e($produk->NAMA_PRODUK); ?></a></div>

                </div>
            </div>

            <div class="container d-flex">

                <div>
                    <div class="single-product-gallery-item" id="slide1">
                        <a data-lightbox="image-1" data-title="Gallery" href="">
                            <img class="img-responsive" alt="" src="<?php echo e(url('Image/' . $produk->GAMBAR)); ?>" width="400px"
                                height="400px" />
                        </a>
                    </div>
                </div>
                <div style="margin-top: 40px; margin-left:10px">
                    <h3> <?php echo e($produk->NAMA_PRODUK); ?></h3>
                    <h5>Rp. <?php echo e($produk->HARGA); ?></h5>
                    <p>Stok : <?php echo e($produk->JUMLAH); ?></p>
                    <p>KATEGORI : <?php echo e($produk->KATEGORI); ?></p>
                    <article><?php echo e($produk->DESKRIPSI); ?></article>
                    <p style="margin-top:20px"><b>Tambah stok:</b></p>
                    <form action="<?php echo e(route('tambahStok', $produk->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <div class="d-flex">
                            <input type="text" name="STOK" class="form-control">
                            <input type="hidden" name="STOK2" class="form-control" value="<?php echo e($produk->JUMLAH); ?>">
                            <button class="btn btn-primary" type="submit">Add</button>
                        </div>
                    </form>
                </div>

            </div>



        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\suyo-mart\resources\views/detailProduk.blade.php ENDPATH**/ ?>