<footer class="main-footer">
    <div class="footer-left">
      Copyright &copy; 2020 <div class="bullet"></div><a href="https://nauval.in/">Aku Siapa?</a>
    </div>
    <div class="footer-right">
      1.0.0
    </div>
  </footer><?php /**PATH E:\1. Kuliah\2. Semester 4\7. Pemograman WEB\suyo-mart\resources\views/layouts/footer.blade.php ENDPATH**/ ?>