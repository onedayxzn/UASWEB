<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2021
    </div>
    <div class="footer-right">
        1.0.0
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\suyo-mart\resources\views/layouts/footer.blade.php ENDPATH**/ ?>