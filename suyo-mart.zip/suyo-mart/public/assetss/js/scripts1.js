$(document).ready(function(){
    $(".openbutton").click(function(){
      $(".open").show();
    });
  });