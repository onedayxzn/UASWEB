-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Jun 2021 pada 19.18
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbsuyomart`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_05_31_124219_create_produks_table', 1),
(5, '2021_05_31_124414_create_pesanans_table', 1),
(6, '2021_05_31_143257_add_softdeletes', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanans`
--

CREATE TABLE `pesanans` (
  `ID_PESANAN` bigint(20) UNSIGNED NOT NULL,
  `NAMA_KONSUMEN` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ID_PRODUK` bigint(20) NOT NULL,
  `NAMA_PRODUK` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `HARGA` bigint(20) NOT NULL,
  `JUMLAH_BELI` bigint(20) NOT NULL,
  `JUMLAH_BAYAR` bigint(20) NOT NULL,
  `TANGGAL_PESAN` date NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pesanans`
--

INSERT INTO `pesanans` (`ID_PESANAN`, `NAMA_KONSUMEN`, `ID_PRODUK`, `NAMA_PRODUK`, `HARGA`, `JUMLAH_BELI`, `JUMLAH_BAYAR`, `TANGGAL_PESAN`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Sukma Ramadhan', 1, 'Soto', 1000, 2, 2000, '2021-06-10', NULL, '2021-06-10 16:55:50', '2021-06-10 16:55:50'),
(2, 'Listyo Adi', 2, 'Nasi Uduk', 10000, 5, 50000, '2021-06-10', NULL, '2021-06-10 16:56:08', '2021-06-10 16:56:08'),
(3, 'Naufal', 11, 'Pani puuri', 2000, 5, 10000, '2021-06-11', NULL, '2021-06-10 17:09:46', '2021-06-10 17:09:46');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produks`
--

CREATE TABLE `produks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `NAMA_PRODUK` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `KATEGORI` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `JUMLAH` bigint(20) NOT NULL,
  `HARGA` bigint(20) NOT NULL,
  `GAMBAR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DESKRIPSI` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `produks`
--

INSERT INTO `produks` (`id`, `NAMA_PRODUK`, `KATEGORI`, `JUMLAH`, `HARGA`, `GAMBAR`, `DESKRIPSI`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Soto', 'INDONESIA FOOD', 20, 1000, 'Soto.png', 'Ini soto', '2021-06-10 15:48:36', '2021-06-10 17:00:45', NULL),
(2, 'Nasi Uduk', 'INDONESIA FOOD', 15, 10000, 'Nasi Uduk.png', 'Ini nasi uduk', '2021-06-10 16:49:30', '2021-06-10 16:56:08', NULL),
(3, 'aa', 'INDONESIA FOOD', 234, 234, 'aa.png', 'sdffsd', '2021-06-10 16:50:47', '2021-06-10 16:52:11', '2021-06-10 16:52:11'),
(4, 'sd', 'JAPANESE FOOD', 3, 2222, 'sd.png', 'sd', '2021-06-10 16:51:59', '2021-06-10 16:52:08', '2021-06-10 16:52:08'),
(5, 'Bibimbap', 'KOREAN FOOD', 20, 15000, 'Bibimbap.png', 'ini nasi campur versi korea', '2021-06-10 16:59:34', '2021-06-10 16:59:34', NULL),
(6, 'coba', 'INDONESIA FOOD', 1, 1, 'coba.png', 'iasdkjaskjdkasd', '2021-06-10 17:01:22', '2021-06-10 17:01:29', '2021-06-10 17:01:29'),
(7, 'Sannakji', 'KOREAN FOOD', 10, 50000, 'Sannakji.png', 'Gurita hidup, dengan sedikit wijen diatasnya', '2021-06-10 17:03:23', '2021-06-10 17:03:23', NULL),
(8, 'Ramen', 'JAPANESE FOOD', 10, 45000, 'Ramen.png', 'Ini ramen langganan naruto', '2021-06-10 17:05:13', '2021-06-10 17:05:13', NULL),
(9, 'tempura', 'JAPANESE FOOD', 10, 5000, 'tempura.png', 'gorengan versi jepang', '2021-06-10 17:06:07', '2021-06-10 17:06:07', NULL),
(10, 'Butter Chicken', 'INDIAN FOOD', 10, 20000, 'Butter Chicken.png', 'Ayam mentega, dengan cita rasa manis gurih', '2021-06-10 17:07:47', '2021-06-10 17:07:47', NULL),
(11, 'Pani puuri', 'INDIAN FOOD', 95, 2000, 'Pani puuri.png', 'Hmmmm, tampaknya lezat', '2021-06-10 17:08:44', '2021-06-10 17:09:46', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_telepon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `alamat`, `no_telepon`, `avatar`, `deleted_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Sukma Ramadhan Asri', 'sukmaramadhan@gmail.com', NULL, '$2y$10$gPfMazTLrCHBnrllxi/YIO9tEMXSbqWEeHSYseQu9Td474JNhgGT6', '\'Jl Pasir Huni raya 320/25A Bandung', '0818787878787', NULL, NULL, NULL, '2021-06-10 15:34:58', '2021-06-10 15:34:58'),
(2, 'Listyo Adi Pamungkas', 'Listyoadi@gmail.com', NULL, '$2y$10$Ir.G3joeap5Zmzzz7gQlzuHpVKdZ.IjZEQ13R2KKbmPr3qu2VoCmK', 'Bandung', '08787127382738', NULL, NULL, NULL, '2021-06-10 15:36:58', '2021-06-10 15:36:58');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `pesanans`
--
ALTER TABLE `pesanans`
  ADD PRIMARY KEY (`ID_PESANAN`);

--
-- Indeks untuk tabel `produks`
--
ALTER TABLE `produks`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `pesanans`
--
ALTER TABLE `pesanans`
  MODIFY `ID_PESANAN` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `produks`
--
ALTER TABLE `produks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
